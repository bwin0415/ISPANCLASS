<template>
    <div>
        <button @click="addCount"> Add </button>
        <h2> {{count}} </h2>
    </div>
</template>

<script>
import store from './store'    // 若不去修改 main.js ，要在這裡引用 store

export default {
    methods: {
        addCount(){
            // this.$store.commit('addStoreCount')
            store.commit('addStoreCount')
        },
    },
    computed: {
        count(){
            // return this.$store.state.count
            return store.state.count
        },
    },
}
</script>