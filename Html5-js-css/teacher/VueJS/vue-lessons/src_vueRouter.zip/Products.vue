<template>
    <div>
        <h1> [Products] </h1>

        <!-- <h3>{{$route.params.sn}}</h3> -->

        <!-- 要用 computed 處理 -->
        <h3>{{sn}}</h3>
    </div>
</template>

<script>
const products = {
    10: 'Hat',
    20: 'T-shirt',
    30: 'iPad',
    40: 'iPhone',
    50: 'AirPods',
    60: 'Mac Pro',
};

export default {
    computed: {
        sn(){
            // return products[this.$route.params.sn];  // http://localhost:8080/#/products/30
            return products[this.$route.query.sn];      // http://localhost:8080/#/products?sn=30
        }
    },
}
</script>

<style scoped>
h1{
    color: maroon;
    font: bold 40px Comic Sans MS;
}
</style>