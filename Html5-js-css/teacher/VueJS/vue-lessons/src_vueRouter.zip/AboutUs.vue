<template>
    <div>
        <h2>@Us</h2>
    </div>
</template>

<style scoped>
h2{
    font: bold 30px Calibri;
    color: lightcoral;
}
</style>