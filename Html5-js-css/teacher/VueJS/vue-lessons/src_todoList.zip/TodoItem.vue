<template>
    <li class="theItem">{{xyz}}</li>
</template>

<script>
export default {
    props: ['xyz'],
}
</script>

<style>
.theItem{
    font: 14px Tahoma;
    background: #abc;
    margin: 5px;
    padding: 5px;
}
.theItem:hover{
    background: #cba;
    cursor: pointer;
}
</style>