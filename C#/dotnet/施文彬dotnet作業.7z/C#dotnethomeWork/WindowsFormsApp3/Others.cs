﻿using System;
using System.Collections.Generic;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp3
{
    class Others
    {
       public string othername = "";
       public int otherPrice = 0 ;
       public Others(string name, int price)
       {
            othername = name;
            otherPrice = price;
       }
    }

}
